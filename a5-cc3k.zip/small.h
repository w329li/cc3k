#ifndef SMALL_H
#define SMALL_H
#include <string>
#include "gold.h"


class Small: public Gold {
    public:
    Small(); // default ctor
    ~Small(); // dtor

};






#endif
