#ifndef MHOARD_H
#define MHOARD_H
#include "gold.h"
#include <string>


class Mhoard: public Gold {
    public:
    Mhoard(); // default ctor
    ~Mhoard(); // dtor
};







#endif
