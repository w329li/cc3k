#include <iostream>
#include <string>
#include "shade.h"

using namespace std;

Shade::Shade()
  :Player(125,25,25,"Shade") {}

Shade::~Shade() {}




