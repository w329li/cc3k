#ifndef NORMAL_H
#define NORMAL_H
#include <string>
#include "gold.h"

class Normal: public Gold {
    public:
    Normal();
    ~Normal();
};


#endif


