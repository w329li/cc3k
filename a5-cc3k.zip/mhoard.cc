#include "mhoard.h"
#include <string>

using namespace std;

Mhoard:: Mhoard(): Gold(4,"mhoard"){}

Mhoard:: ~Mhoard() {}


