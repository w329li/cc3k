#ifndef HHOARD_H
#define HHOARD_H
#include "gold.h"
#include <string>


class Hhoard: public Gold {
    public:
    Hhoard(); // default ctor
    ~Hhoard(); // dtor
};







#endif
