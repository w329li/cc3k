#include <iostream>
#include <string>
#include "troll.h"

using namespace std;

Troll::Troll():
  Player(120,25,15,"Troll") {}

Troll::~Troll() {}

