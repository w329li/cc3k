#include "small.h"
#include <string>

using namespace std;

Small::Small()
  :Gold(1,"small") {}

Small:: ~Small() {}
