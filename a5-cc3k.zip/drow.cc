#include <iostream>
#include <string>
#include "drow.h"

using namespace std;

Drow::Drow()
  :Player(150,25,15,"Drow"){}


Drow::~Drow() {}
