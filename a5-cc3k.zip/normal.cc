#include <string>
#include "normal.h"


using namespace std;


Normal::Normal(): Gold(2,"normal") {}

Normal:: ~Normal() {}



