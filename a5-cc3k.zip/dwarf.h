
#ifndef DWARF_H
#define DWARF_H

#include "character.h"
#include "enemy.h"
#include <string>

class Dwarf: public Enemy{
public:
    Dwarf(); // default ctor
    ~Dwarf(); // dtor
};

#endif
