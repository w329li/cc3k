#include "hhoard.h"
#include <string>

using namespace std;

Hhoard::Hhoard(): Gold(4,"two normal piles"){}

Hhoard:: ~Hhoard() {}


