#ifndef ORC_H
#define ORC_H
#include "character.h"
#include "enemy.h"

class Orc:public Enemy{
public:
    Orc(); // default ctor
    ~Orc();
};
#endif
