#include "halfling.h"
#include "enemy.h"
using namespace std;

Halfling::Halfling():Enemy(100,15,20,"Halfling","L"){}

Halfling::~Halfling(){}
